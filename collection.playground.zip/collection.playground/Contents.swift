//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//array

var friends : [String]
friends = ["Ishav","Param","Rinku Devi","LA Baburao"]


print("Friends : \(friends)")

for frnd in friends {
    print("Friends : \(frnd)")
}



for itr in 0..<friends.count{
    print("Friends \(friends[itr])")
    
}



for (index,value) in
    friends.enumerated(){
        print("index: \(index) value : \(value)")
}



//printing with range
for frnd in friends[2...]{
    print("Friends : \(frnd)")
}


for frnd in friends[...2]{
    print("Friends : \(frnd)")
}


var numbers  = Array(repeating: 1, count: 4)
print("Numbers: \(numbers)")

numbers[2] = 100
print("Numbers : \(numbers)")

var more = Array(repeating: 0, count: 3)
print("more: \(more)")

var all = numbers + more
print("All : \(all)")

for (index,value) in
    all.enumerated(){
        print("index: \(index) value : \(value)")
}


print("all[9] \(all[3])")


var grocery = ["Bread", "Milk"]
print("Grocery : \(grocery)")

grocery.append("Rice")
grocery += ["Juice","Sher Atta"]
grocery[1...3] = ["Butter","Snacks","Ice Cream"]

grocery.insert("veggies", at: 4)


print("Grocery : \(grocery)")


grocery.removeAll()
if grocery.isEmpty{
    print("No grocery to shop")
}else{
    print("grocery list: \(grocery)")
    
}


//set


var language = Set<String>()
language.insert("Hindi")
language.insert("Punjabi")
language.insert("Gujarati")
language.insert("Potuguese")
language.insert("English")

if language.isEmpty{
    print("No language")
}else{
    
    print("\(language.count) language : \(language)")
}

let motherTongue = ["Guj","Pun","Port","Telu"]
print("motherTongue : \(motherTongue)")

print("Union : \(language.union(motherTongue).sorted())")

print("Intersection : \(language.intersection(motherTongue).sorted())" )

print("Subtracting : \(language.subtracting(motherTongue).sorted())")

print("Symmetric Diffrence : \(language.symmetricDifference(motherTongue).sorted())")





let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

houseAnimals.isSubset(of: farmAnimals)

farmAnimals.isSuperset(of: houseAnimals)

farmAnimals.isDisjoint(with: cityAnimals)





//dictionary
var namesofInt = [Int : String]()
namesofInt[20] = "Twenty"
print("value of key 20 \(namesofInt[20])")

print("namesofInt contains \(namesofInt.count) items")

namesofInt = [:]
if namesofInt.isEmpty{
    print("No item in the dictionary")
}


var HTTP : [Int : String] = [400 : "Bad Request", 402 : "payment required", 404 : "not found", 406 : "not acceptble"]

HTTP[405] = "method not allowed"
print("Error code : \(HTTP)")

let old402 = HTTP.updateValue("reserved for future use", forKey: 402)
print("Error code : \(HTTP)")






for errorCode in HTTP.keys{
    print("error code : \(errorCode)")
    
}

let errorCodeList = HTTP.keys
print("error code list : \(errorCodeList)")


var flight = [String : AnyObject]()
flight["number"] = "AC043" as AnyObject
flight["duration"] = 14 as AnyObject
flight["cost"] = 1600.23 as AnyObject

print("Flight \(flight)")






