//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var Santosh = Customer()
Santosh.customerID = "C101"
//Santosh.customerName = "Santosh"

print(Santosh.displayData())


var param = Customer(customerID: "C102",customerName: "Paramjeet",email: "param@mad.com", address: "Brampton", creditCardInfo: "4520-5642-5964-5632", shippingInfo: "ship to Lambton College North york ")

print(param.displayData())



var Saloni = Customer()
Saloni.registerUser()
print(Saloni.displayData())


Saloni.CustomerName = "Sallu"
Saloni.Shipping = "Deliver between 10AM to 12PM"
print(Saloni.displayData())

Santosh.CustomerName = "Santosh"
Santosh.Email = "S@mad.com"
Santosh.Address = "Downtown"
Santosh.Credit = "4520-6562-6960-1001"
Santosh.Shipping = "Deliver at Ghar"

print(Santosh.displayData())



