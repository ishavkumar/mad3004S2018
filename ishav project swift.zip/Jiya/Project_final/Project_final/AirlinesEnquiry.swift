//
//  AirlinesEnquiry.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class AirlinesEnquiry : Airlines {
    var enquiryID: Int?
    var enquiryType: String?
    var enquiryTitle: String?
    var enquiryDescription : String?
    var enquiryDate : String? //date
    
    
    var EnquiryID: Int?{
        get{return self.enquiryID!}
        set{self.enquiryID = newValue}
    }
    
    var EnquiryType : String?{
        get{return self.enquiryType}
        set{self.enquiryType = newValue}
    }
    
    var EnquiryTitle: String?{
        get{return self.enquiryTitle}
        set{self.enquiryTitle = newValue}
    }
    var EnquiryDescription: String?{
        get{return self.enquiryDescription}
        set{self.enquiryDescription = newValue}
    }
    var EnquiryDate: String?{
        get{return self.enquiryDate}
        set{self.enquiryDate = newValue}
    }
    
    
    required override init(){
        self.enquiryID = 0
        self.enquiryType = ""
        self.enquiryTitle = ""
        self.enquiryDescription = ""
        self.enquiryDate = ""
        super.init()
        
    }
    
    required init(airlinesID : Int, enquiryID: Int, enquiryType : String, enquiryTitle: String, enquiryDescription : String , enquiryDate : String  ){
        super.init(airlinesID: airlinesID)
        self.enquiryID = enquiryID
        self.enquiryType = enquiryType
        self.enquiryTitle = enquiryTitle
        self.enquiryDescription = enquiryDescription
        self.enquiryDate = enquiryDate
       
        
    }
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Airlines Id: \(self.airlinesID)"
        returnData += "\n Enquiry Id: \(self.enquiryID)"
        returnData += "\n Enquiry Type: \(self.enquiryType ?? "")"
        returnData += "\n Enquiry Title: \(self.enquiryTitle ?? "")"
        returnData += "\n Enquiry Description : \(self.enquiryDescription ?? "")"
        returnData += "\n Enquiry Date: \(self.enquiryDate ?? "")"
        
        
        return returnData
    }
    
    func addEnquiry(){
       
        print("Enter Enquiry ID : ")
        self.enquiryID = (Int)(readLine()!)!
        print("Enter Enquiry Type : ")
        self.enquiryType = readLine()!
        print("Enter Enquiry Title : ")
        self.enquiryTitle = readLine()!
        print("Enter Enquiry Description : ")
        self.enquiryDescription = readLine()!
        print("Enter Enquiry Date : ")
        self.enquiryDate = readLine()!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // This formate is input formated .
        
        let formateDate = dateFormatter.date(from:enquiryDate!)!
        dateFormatter.dateFormat = "MM-dd-yyyy" // Output Formated
        
        print ("Print :\(dateFormatter.string(from: formateDate))")//Print :02-02-2018
        enquiryDate = dateFormatter.string(from: formateDate)
        
    }
}


