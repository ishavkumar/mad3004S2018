//
//  Util.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//


import Foundation

class Util{
    static func drawLine()
    {
        let line = String(repeating: "-", count: 100)
        print(line)
    }
}
