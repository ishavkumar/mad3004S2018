//
//  Airlines.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Airlines : IDisplay {
    var airlinesID: Int?
    var airlinesDescription : String?
    var airlinesType : String?
    
    
    var AirlinesID: Int?{
        get{return self.airlinesID!}
        set{self.airlinesID = newValue}
    }
    
    var AirlinesDescription : String?{
        get{return self.airlinesType}
        set{self.airlinesDescription = newValue}
    }
    
    var AirlinesType: String?{
        get{return self.airlinesType}
        set{self.airlinesType = newValue}
    }
    
    
    init(){
        self.airlinesID = 0
        self.airlinesDescription = ""
        self.airlinesType = ""
        
        
    }
    
    init(airlinesID :Int, airlinesDescription: String, airlinesType: String){
        
        self.airlinesID = airlinesID
        self.airlinesDescription = airlinesDescription
        self.airlinesType = airlinesType
        
        
    }
    
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Airlines Id: \(self.airlinesID)"
        returnData += "\n Airlines Description: \(self.airlinesDescription ?? "")"
        returnData += "\n Airlines Type : \(self.airlinesType ?? "")"
        
        
        return returnData
    }
    
    func addAirlines(){
        print("Enter Airlines ID : ")
        self.AirlinesID = (Int)(readLine()!)!
        print("Enter Airlines Description : ")
        self.airlinesDescription = readLine()!
        print("Enter Airlines Type : ")
        self.airlinesType = readLine()!
        
        
        
        
        
        
        
    }
}


